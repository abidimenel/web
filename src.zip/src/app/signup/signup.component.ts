import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
})
export class SignupComponent {
  email: string = '';
  password: string = '';
  confirmPassword: string = '';
  errorMessage: string = '';  // Variable pour afficher les erreurs

  constructor(private router: Router) {}

  onSubmit(): void {
    // Reset error message at the start of each submission
    this.errorMessage = '';

    if (this.password === this.confirmPassword) {
      // Logique d'inscription ici (ici, juste un log)
      console.log('Signing up with email:', this.email);

      // Redirection vers la page de connexion après l'inscription
      this.router.navigate(['/login']);
    } else {
      // Si les mots de passe ne correspondent pas
      this.errorMessage = 'Les mots de passe ne correspondent pas';
    }
  }
}
