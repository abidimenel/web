import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  email: string = '';
  password: string = '';
  errorMessage: string = ''; // Variable pour le message d'erreur

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit() {
    // Appel au service d'authentification
    this.authService.login(this.email, this.password).subscribe(
      (response) => {
        // Si la connexion réussit, on redirige l'utilisateur
        this.router.navigate(['/home']);
      },
      (error) => {
        // Si la connexion échoue, on affiche un message d'erreur
        this.errorMessage = 'Invalid email or password'; // Message d'erreur personnalisé
      }
    );
  }
}
