import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  // Définir les menus et leur état d'ouverture
  menuOpen: { [key: string]: boolean } = {
    employees: false,
    sim: false,
    numbers: false
  };

  constructor(private router: Router) {}

  /**
   * Permet de basculer l'état d'affichage des menus
   */
  toggleMenu(menu: 'employees' | 'sim' | 'numbers'): void {
    this.menuOpen[menu] = !this.menuOpen[menu];
  }

  /**
   * Vérifie si l'utilisateur est authentifié (en fonction du token)
   */
  isAuthenticated(): boolean {
    return !!localStorage.getItem('token'); // Vérifie la présence du token
  }

  /**
   * Déconnexion de l'utilisateur
   */
  onLogout(): void {
    localStorage.removeItem('token'); // Supprimer le token de l'utilisateur
    this.router.navigate(['/login']); // Rediriger vers la page de connexion
  }
}
