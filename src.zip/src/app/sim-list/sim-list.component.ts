import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sim-list',
  templateUrl: './sim-list.component.html',
  styleUrls: ['./sim-list.component.css'],
})
export class SimListComponent implements OnInit {
  sims: any[] = []; // Liste des puces
  searchQuery: string = ''; // Recherche

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    // Requête HTTP pour récupérer les données spécifiques depuis le backend
    this.http.get<any[]>('http://localhost:3000/sims').subscribe(
      (data) => {
        this.sims = data; // Stocker les données spécifiques
      },
      (error) => {
        console.error('Erreur lors de la récupération des puces', error);
      }
    );
  }

  /**
   * Filtrer les puces selon la recherche.
   */
  filterSims(): any[] {
    const query = this.searchQuery.toLowerCase();
    return this.sims.filter((sim) =>
      sim.serialNumber.toLowerCase().includes(query) ||
      sim.dateDajout.toLowerCase().includes(query) ||
      sim.dateAttribution.toLowerCase().includes(query)
    );
  }
}
