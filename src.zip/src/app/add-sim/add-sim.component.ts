import { Component } from '@angular/core';

@Component({
  selector: 'app-add-sim',
  templateUrl: './add-sim.component.html',
  styleUrls: ['./add-sim.component.css'],
})
export class AddSimComponent {
  barcodeValue: string | null = ''; // Valeur du code barre actuellement scanné
  scannedChips: any[] = []; // Liste des puces scannées
  editingChip: any = null; // Chip en cours d'édition (si applicable)

  // Méthode appelée lorsque le code barre est scanné ou saisi manuellement
  onBarcodeScanned(): void {
    if (this.barcodeValue && this.barcodeValue.trim()) {
      if (this.editingChip) {
        // Si on est en mode édition, on met à jour la puce existante
        this.updateChip(this.barcodeValue.trim());
      } else {
        // Sinon, on ajoute une nouvelle puce
        this.addChipToList(this.barcodeValue.trim());
      }
    }
  }

  // Ajouter une puce à la liste locale
  addChipToList(barcode: string): void {
    const newChip = {
      barcode,
      status: 'non validé', // Statut initial de la puce
    };
    this.scannedChips.push(newChip); // Ajouter la puce à la liste
    this.barcodeValue = ''; // Réinitialiser la valeur du champ
  }

  // Mettre à jour une puce dans la liste
  updateChip(barcode: string): void {
    if (this.editingChip) {
      this.editingChip.barcode = barcode; // Modifier le code barre de la puce
      this.editingChip = null; // Réinitialiser l'édition
    }
    this.barcodeValue = ''; // Réinitialiser la valeur du champ
  }

  // Méthode pour éditer un code barre
  editBarcode(chip: any): void {
    this.barcodeValue = chip.barcode; // Remplir la zone de saisie avec le code sélectionné
    this.editingChip = chip; // Marquer la puce comme étant en édition
  }

  // Méthode pour supprimer une puce de la liste
  deleteChip(chip: any): void {
    this.scannedChips = this.scannedChips.filter(c => c !== chip); // Supprimer la puce sélectionnée
  }
}
