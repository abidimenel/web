import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class EmployeeService {
  private apiUrl = 'http://localhost:3000/api/employees'; // URL de votre backend pour les employés
  private simApiUrl = 'http://localhost:3000/api/sims'; // URL de votre backend pour les SIMs
  private emailApiUrl = 'https://your-email-api.com/send'; // Remplacez par votre API d'envoi d'emails.

  constructor(private http: HttpClient) {}

  /**
   * Attribue un numéro de téléphone à un employé ou une SIM.
   * @param formData Les données du formulaire contenant le serialNumber et le numTelephone.
   * @returns Observable de la réponse de l'API.
   */
  assignNumber(formData: { serialNumber: string; numTelephone: string }): Observable<any> {
    return this.http.post(`${this.simApiUrl}/assign-number`, formData);
  }

  /**
   * Attribue une SIM à un employé.
   * @param formData Les données du formulaire contenant les détails de l'employé et de la SIM.
   * @returns Observable de la réponse de l'API.
   */
  assignSim(formData: {
    nom: string;
    cin: string;
    poste: string;
    service: string;
    forfait: string;
    forfaitInternet: string;
    serialNumber: string;
  }): Observable<any> {
    return this.http.post(`${this.simApiUrl}/assign-sim`, formData);
  }

  /**
   * Récupère la liste des employés depuis le backend.
   * @returns Observable avec la liste des employés.
   */
  getEmployees(): Observable<any> {
    return this.http.get(`${this.apiUrl}`);
  }

  /**
   * Met à jour un employé avec des données spécifiques.
   * @param id L'identifiant de l'employé.
   * @param updatedData Les données mises à jour (exemple : numéro de téléphone).
   * @returns Observable de la réponse de l'API.
   */
  updateEmployee(id: string, updatedData: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, updatedData);
  }

  /**
   * Envoie les détails de l'attribution via un email.
   * @param emailData Les données du formulaire à envoyer.
   * @returns Observable de la réponse de l'API.
   */
  sendEmail(emailData: any): Observable<any> {
    const emailPayload = {
      to: 'societe@exemple.com', // Adresse email de destination.
      subject: 'Attribution de SIM et forfait',
      body: `
        Voici les détails de l'attribution :
        Nom: ${emailData.nom}
        CIN: ${emailData.cin}
        Poste: ${emailData.poste}
        Service: ${emailData.service}
        Forfait: ${emailData.forfait}
        Forfait Internet: ${emailData.forfaitInternet}
        Serial Number: ${emailData.serialNumber}
      `,
    };

    return this.http.post(this.emailApiUrl, emailPayload);
  }
}
