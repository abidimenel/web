import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-assign-number',
  templateUrl: './assign-number.component.html',
  styleUrls: ['./assign-number.component.css'],
})
export class AssignNumberComponent implements OnInit {
  assignForm: FormGroup;

  constructor(private fb: FormBuilder, private employeeService: EmployeeService) {
    // Initialisation du formulaire
    this.assignForm = this.fb.group({
      serialNumber: ['', Validators.required],
      numTelephone: [
        '',
        [Validators.required, Validators.pattern('^[0-9]{8}$')], // Validation pour un numéro à 8 chiffres
      ],
    });
  }

  ngOnInit(): void {}

  /**
   * Gérer l'entrée dans le champ Serial Number
   */
  onSerialNumberInput(event: any): void {
    const serialNumber = event.target.value;
    console.log('Serial Number scanné:', serialNumber);
  }

  /**
   * Gérer la soumission du formulaire
   */
  onSubmit(): void {
    if (this.assignForm.valid) {
      const formData = this.assignForm.value;

      this.employeeService.assignNumber(formData).subscribe(
        (response: any) => {
          alert('Numéro de téléphone attribué avec succès!');
        },
        (error: any) => {
          alert('Erreur lors de l\'attribution du numéro de téléphone.');
        }
      );
    }
  }
}
