import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  login(email: string, password: string): Observable<any> {
    // Remplacez ceci par votre logique d'authentification réelle
    if (email === 'test@example.com' && password === 'password') {
      return of({ success: true });
    }
    return of({ success: false });
  }
}
