import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-assign-sim',
  templateUrl: './assign-sim.component.html',
  styleUrls: ['./assign-sim.component.css']
})
export class AssignSimComponent implements OnInit {
  assignForm: FormGroup;
  forfait = '50 DT';
  forfaitInternet = '15 Go';
  detailsVisible = false;

  constructor(private fb: FormBuilder, private employeeService: EmployeeService) {
    // Initialisation du formulaire
    this.assignForm = this.fb.group({
      nom: ['', [Validators.required]],
      cin: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(8)]],
      poste: ['', Validators.required],
      service: ['', Validators.required],
      forfait: [{ value: this.forfait, disabled: true }, Validators.required],
      forfaitInternet: [{ value: this.forfaitInternet, disabled: true }, Validators.required],
      serialNumber: ['', Validators.required],
    });
  }

  ngOnInit(): void {}

  /**
   * Gérer le changement de poste et modifier automatiquement le forfait.
   */
  onPosteChange(): void {
    const poste = this.assignForm.get('poste')?.value;
    if (poste === 'technicien') {
      this.forfait = '30 DT';
    } else if (poste === 'specialiste') {
      this.forfait = '50 DT';
    } else if (poste === 'manager') {
      this.forfait = '70 DT';
    } else if (poste === 'directeur') {
      this.forfait = '100 DT';
    }
    this.assignForm.get('forfait')?.setValue(this.forfait);
  }

  /**
   * Gérer l'entrée dans le champ Serial Number.
   */
  onSerialNumberInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    const serialNumber = input.value.trim();
    this.assignForm.get('serialNumber')?.setValue(serialNumber);
  }

  /**
   * Afficher les détails dans le modal.
   */
  onSubmit(): void {
    if (this.assignForm.valid) {
      this.detailsVisible = true;
    }
  }

  /**
   * Fermer le modal.
   */
  closeModal(): void {
    this.detailsVisible = false;
  }

  /**
   * Envoyer les détails par email.
   */
  sendEmail(): void {
    const formData = this.assignForm.getRawValue();
    const emailData = {
      nom: formData.nom,
      cin: formData.cin,
      poste: formData.poste,
      service: formData.service,
      forfait: this.forfait,
      forfaitInternet: this.forfaitInternet,
      serialNumber: formData.serialNumber,
    };

    this.employeeService.sendEmail(emailData).subscribe(
      (response: any) => {
        alert('Email envoyé avec succès.');
        this.closeModal();
      },
      (error: any) => {
        alert('Échec de l\'envoi de l\'email.');
      }
    );
  }

  /**
   * Imprimer les détails.
   */
  printDetails(): void {
    const formData = this.assignForm.getRawValue();
    const printContent = `
      Nom: ${formData.nom}\n
      CIN: ${formData.cin}\n
      Poste: ${formData.poste}\n
      Service: ${formData.service}\n
      Forfait: ${this.forfait}\n
      Forfait Internet: ${this.forfaitInternet}\n
      Serial Number: ${formData.serialNumber}
    `;
    console.log(printContent);
    alert('Impression simulée. Voir la console pour les détails.');
  }
}
