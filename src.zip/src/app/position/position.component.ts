// src/app/position/position.component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-position',
  templateUrl: './position.component.html',
  styleUrls: ['./position.component.css']
})
export class PositionComponent {
  position = { name: '', internetPackage: '' };
  positions = [
    { name: 'Technician', internetPackage: 'Basic Package' },
    { name: 'Specialist', internetPackage: 'Standard Package' },
    { name: 'Manager', internetPackage: 'Premium Package' },
    { name: 'Director', internetPackage: 'Executive Package' }
  ];

  addPosition() {
    if (this.position.name && this.position.internetPackage) {
      this.positions.push({ ...this.position });
    }
    this.position = { name: '', internetPackage: '' };
  }
}
